# Outliers


```python
import pandas as pd
from scipy import stats
import numpy as np
import matplotlib.pyplot as plt

```


```python
data= pd.DataFrame({
    "Study_Hours":[1,2,3,4,5,6,7,8,20]
})
data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Study_Hours</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
    </tr>
    <tr>
      <th>5</th>
      <td>6</td>
    </tr>
    <tr>
      <th>6</th>
      <td>7</td>
    </tr>
    <tr>
      <th>7</th>
      <td>8</td>
    </tr>
    <tr>
      <th>8</th>
      <td>20</td>
    </tr>
  </tbody>
</table>
</div>




```python
data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Study_Hours</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>9.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>6.222222</td>
    </tr>
    <tr>
      <th>std</th>
      <td>5.651942</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>3.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>5.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>7.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>20.000000</td>
    </tr>
  </tbody>
</table>
</div>



# IQR Method


```python
Q1 = data.quantile(0.25)
Q3 = data.quantile(0.75)
IQR = Q3 - Q1
LB=Q1-1.5*IQR
UB=Q3+1.5*IQR
outliners=data[(data<(LB))|(data>(UB))]
```


```python
outliners
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Study_Hours</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>NaN</td>
    </tr>
    <tr>
      <th>5</th>
      <td>NaN</td>
    </tr>
    <tr>
      <th>6</th>
      <td>NaN</td>
    </tr>
    <tr>
      <th>7</th>
      <td>NaN</td>
    </tr>
    <tr>
      <th>8</th>
      <td>20.0</td>
    </tr>
  </tbody>
</table>
</div>



# Z- Score method


```python
data= pd.DataFrame({
    "Study_Hours":[1,2,3,4,5,6,7,8,20]
})
data

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Study_Hours</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
    </tr>
    <tr>
      <th>5</th>
      <td>6</td>
    </tr>
    <tr>
      <th>6</th>
      <td>7</td>
    </tr>
    <tr>
      <th>7</th>
      <td>8</td>
    </tr>
    <tr>
      <th>8</th>
      <td>20</td>
    </tr>
  </tbody>
</table>
</div>




```python
z_score = np.abs(stats.zscore(data["Study_Hours"]))
outliers = data[z_score > 2]
outliers
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Study_Hours</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>8</th>
      <td>20</td>
    </tr>
  </tbody>
</table>
</div>




```python
stats.zscore(data["Study_Hours"])
```




    array([-0.98001775, -0.79235477, -0.6046918 , -0.41702883, -0.22936586,
           -0.04170288,  0.14596009,  0.33362306,  2.58557873])




```python
plt.scatter(range(len(data)),data["Study_Hours"])
plt.xlabel("Index")
plt.ylabel("Study Hours")
plt.title("Scatter Plot showing Outliers")
plt.show()
```


    
![png](output_11_0.png)
    



```python
plt.hist(data["Study_Hours"],bins=6)
plt.xlabel("Study Hours")
plt.ylabel("Frequency")
plt.title("Histogram showing Outliers Effect")
plt.show()
```


    
![png](output_12_0.png)
    



```python
plt.hist(data["Study_Hours"],40)
plt.xlabel("Study Hours")
plt.ylabel("Frequency")
plt.title("Histogram showing Outliers Effect")
plt.show()
```


    
![png](output_13_0.png)
    



```python

```
